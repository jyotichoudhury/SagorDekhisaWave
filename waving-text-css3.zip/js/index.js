var text = "I wanna Wowow!";

for(var i in text) { 
  if(text[i] === " ") {
    $(".wavetext").append( $("<span>").html("&nbsp;") ); 
  } else if (text[i]==='n') {
    $(".wavetext").append("<br>")
  }
  
  else {  
    $(".wavetext").append( $("<span>").text(text[i]) ); 
  }
}